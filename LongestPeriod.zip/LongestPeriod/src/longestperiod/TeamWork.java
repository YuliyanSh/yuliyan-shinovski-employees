package longestperiod;


public class TeamWork {
    private int empID1;
    private int empID2;
    private long duration;
    private String projects;

    
    public TeamWork(int empID1, int empID2, long duration, String projects) {
        setEmpID1(empID1);
        setEmpID2(empID2);
        setDuration(duration);
        setProjects(projects);
    }

    public TeamWork() {
        this(1, 1, 0, "");
    }
    
    
    public int getEmpID1() {
        return empID1;
    }

    public void setEmpID1(int empID1) {
        if (empID1 > 0) {
            this.empID1 = empID1;
        } else {
            this.empID1 = 1;
        }
    }

    public int getEmpID2() {
        return empID2;
    }

    public void setEmpID2(int empID2) {
        if (empID2 > 0) {
            this.empID2 = empID2;
        } else {
            this.empID2 = 1;
        }
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        if (duration > 0) {
            this.duration = duration;
        } else {
            this.duration = 0;
        }
    }

    public String getProjects() {
        return projects;
    }

    public void setProjects(String projects) {
        this.projects = projects;
    }
    
    
    public void addDuration(long duration) {
        this.duration += duration;
    }
    
    public void addProject(String project) {
        projects = projects + " " + project;
    }

    
    @Override
    public String toString() {
        return String.format("%4d %4d %10s %10s", this.getEmpID1(), this.getEmpID2(), this.getDuration(), this.getProjects());    
    }
     
}
