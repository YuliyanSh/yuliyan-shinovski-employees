package longestperiod;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import static java.time.temporal.ChronoUnit.DAYS;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class LongestPair {
    private static String fileName = "resources\\employees1.txt";
    public static List<TeamWork> result = new ArrayList<TeamWork>();
    
    public static void setFileName(String newFileName) {
        fileName = newFileName;
    }
    
    /**
     * 
     * @param inputString
     * @param knownPatterns
     * @return LocalDate if matched to an existing date pattern
     */
    public static LocalDate matchPattern(String inputString, List<DateTimeFormatter> knownPatterns) {
        for (DateTimeFormatter knownPattern : knownPatterns) {
            try{
                return LocalDate.parse(inputString, knownPattern);       
            }
            catch(DateTimeParseException dtpe) {

            }
        }
        throw new IllegalArgumentException("Invalid input for date. Given '"+inputString);
    }
    
    /**
     * 
     * @param employee1
     * @param employee2
     * @return number of shared days between two workData on the same project
     */
    public static long getSharedDays(WorkData employee1, WorkData employee2) {
        LocalDate start = employee2.getDateFrom().isAfter(employee1.getDateFrom())
                ? employee2.getDateFrom()
                : employee1.getDateFrom();
        LocalDate end = employee2.getDateTo().isAfter(employee1.getDateTo())
                ? employee1.getDateTo() 
                : employee2.getDateTo();

        return DAYS.between(start, end) > 0 ? DAYS.between(start, end) : 0;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int empID;
        int projectID;
        LocalDate dateFrom;
        LocalDate dateTo;
        
        String line = null; // reference one line at a time
        
        List<WorkData> workData = new ArrayList<WorkData>();
        List<TeamWork> teamWorkData = new ArrayList<TeamWork>();
        
        /* List of patterns to be matched to a date */
        List<DateTimeFormatter> knownPatterns = new ArrayList<DateTimeFormatter>();
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        DateTimeFormatter formatter4 = DateTimeFormatter.ofPattern("dd MM yyyy");
        DateTimeFormatter formatter5 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter formatter6 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        DateTimeFormatter formatter7 = DateTimeFormatter.ofPattern("yyyy.MM.dd");
        DateTimeFormatter formatter8 = DateTimeFormatter.ofPattern("yyyy MM dd");
        knownPatterns.add(formatter1);
        knownPatterns.add(formatter2);
        knownPatterns.add(formatter3);
        knownPatterns.add(formatter4);
        knownPatterns.add(formatter5);
        knownPatterns.add(formatter6);
        knownPatterns.add(formatter7);
        knownPatterns.add(formatter8); 
        
        
        /* Reading the data from the file */
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                // Split into tokens
                String[] result = line.split("[ ,]+", 4);
                
                // Get data from the tokens
                empID = Integer.parseInt(result[0]);
                projectID = Integer.parseInt(result[1]);
                dateFrom = matchPattern(result[2], knownPatterns);
                if (!result[3].matches("NULL")) {
                    dateTo = matchPattern(result[3], knownPatterns);
                } else {
                    dateTo = LocalDate.now();
                }
                
                WorkData employee = new WorkData(empID, projectID, dateFrom, dateTo);
                workData.add(employee);
            }   

            // Close files
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" + fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println("Error reading file '" + fileName + "'");                  
        }
                   
         
        
        Map<Integer, List<WorkData>> groupedByProjectID = 
                workData.stream().collect(Collectors.groupingBy(e -> e.getProjectID()));
        
        groupedByProjectID.forEach((Integer project, List<WorkData> employeesInProject) -> {     
            for (int i = 0; i < employeesInProject.size()-1; i++) {
                for (int j = i+1; j < employeesInProject.size(); j++) {  
                    if (employeesInProject.get(i).getEmpID() == employeesInProject.get(j).getEmpID()) {
                        continue;
                    }
                    if (getSharedDays(employeesInProject.get(i), employeesInProject.get(j)) == 0) {
                        continue;
                    }
                    TeamWork  nextPair = new TeamWork(
                            employeesInProject.get(i).getEmpID(), 
                            employeesInProject.get(j).getEmpID(), 
                            getSharedDays(employeesInProject.get(i), employeesInProject.get(j)), 
                            Integer.toString(employeesInProject.get(i).getProjectID()));
                   
                    boolean exists = false;
                    for (TeamWork sharedProjects : teamWorkData) {
                        if ((sharedProjects.getEmpID1() == nextPair.getEmpID1() && sharedProjects.getEmpID2() == nextPair.getEmpID2())
                                || (sharedProjects.getEmpID1() == nextPair.getEmpID2() && sharedProjects.getEmpID2() == nextPair.getEmpID1())) { 
                            exists = true;
                            sharedProjects.addDuration(nextPair.getDuration());
                            sharedProjects.addProject(nextPair.getProjects());
                        } 
                    }
                    
                    if (!exists) {
                        teamWorkData.add(nextPair);
                    }
                } 
            }      
        });
        
        // Print information about the pairs that have worked the longest together
        Comparator<TeamWork> cmp = Comparator.comparing(TeamWork::getDuration);
        
        if (!teamWorkData.isEmpty()) {
            long longest = teamWorkData.stream().max(cmp).get().getDuration();
            System.out.printf("Employee ID #1  Employee ID #2  Project ID  Days worked%n");
            teamWorkData.stream().filter(s -> s.getDuration() == longest)
                .forEach(e -> {
                    System.out.printf("%14s  %14s  %10s  %11s%n",
                        e.getEmpID1(),
                        e.getEmpID2(),
                        e.getProjects(),
                        e.getDuration());
                    result.add(e);
                });  
        } else {
            System.out.println("Insufficient information from file");
        }
        
        
        //teamWorkData.stream().filter(s -> s.getDuration() == longest).;
    }
    
}
