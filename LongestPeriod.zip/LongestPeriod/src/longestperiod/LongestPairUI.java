package longestperiod;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


public class LongestPairUI extends Application {
    
    @Override
    public void start(final Stage stage) throws Exception {
        Button button = new Button("Choose file...");
        Label chosen = new Label();
        button.setOnAction(event -> {
            FileChooser chooser = new FileChooser();
            File file = chooser.showOpenDialog(stage);
            if (file != null) {
                String fileAsString = file.toString();
                LongestPair.setFileName(fileAsString);
                String[] args = {};
                LongestPair.main(args);
                makeGrid(LongestPair.result);
                LongestPair.result = new ArrayList<TeamWork>();
                chosen.setText("Chosen: " + fileAsString);
            } else {
                chosen.setText(null);
            }
        });
        
        VBox layout = new VBox(10, button, chosen);
        layout.setMinWidth(400);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(10));
        stage.setScene(new Scene(layout));
        stage.setTitle("File chooser");
        stage.show();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Opens a new window to show the result in it
     * @param result 
     */
    private void makeGrid(List<TeamWork> result) {
        GridPane outputGridPane = new GridPane();
        Label lblEmpID1 = new Label("Employee ID #1");
        Label lblEmpID2 = new Label("Employee ID #2");
        Label lblProjectID = new Label("Project ID");
        Label lblDysWorked = new Label("Days worked");
        GridPane.setConstraints(lblEmpID1, 0, 0);
        GridPane.setConstraints(lblEmpID2, 1, 0);
        GridPane.setConstraints(lblProjectID, 2, 0);
        GridPane.setConstraints(lblDysWorked, 3, 0);
        outputGridPane.getChildren().addAll(lblEmpID1, lblEmpID2, lblProjectID, lblDysWorked);
        
        int nextRowNumber = 1;
        
        for (TeamWork teamWork : result) {
            Label lblResultEmpID1 = new Label(Integer.toString(teamWork.getEmpID1()));
            Label lblResultEmpID2 = new Label(Integer.toString(teamWork.getEmpID2()));
            Label lblResultProjectID = new Label(teamWork.getProjects());
            Label lblResultDaysWorked = new Label(Long.toString(teamWork.getDuration()));
            GridPane.setConstraints(lblResultEmpID1, 0, nextRowNumber);
            GridPane.setConstraints(lblResultEmpID2, 1, nextRowNumber);
            GridPane.setConstraints(lblResultProjectID, 2, nextRowNumber);
            GridPane.setConstraints(lblResultDaysWorked, 3, nextRowNumber);
            nextRowNumber++;
            
            outputGridPane.getChildren().addAll(lblResultEmpID1, lblResultEmpID2, lblResultProjectID, lblResultDaysWorked);
        }
        
        outputGridPane.setHgap(6);
        outputGridPane.setVgap(6);
        outputGridPane.setAlignment(Pos.CENTER);
        
        Stage stage = new Stage();
        outputGridPane.setMinWidth(400);
        outputGridPane.setPadding(new Insets(10));
        stage.setScene(new Scene(outputGridPane));
        stage.setTitle("Result");
        stage.show();

    }
    
}
