package longestperiod;

import java.time.LocalDate;
import static java.time.temporal.ChronoUnit.DAYS;


public class WorkData {
    private int empID;
    private int projectID;
    private LocalDate dateFrom;
    private LocalDate dateTo;

    
    public WorkData(int empID, int projectID, LocalDate dateFrom, LocalDate dateTo) {
        setEmpID(empID);
        setProjectID(projectID);
        setDateFrom(dateFrom);
        setDateTo(dateTo);
    }
    
    public WorkData() {
        this(1, 1, LocalDate.now(), LocalDate.now());
    }
    
    
    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        if (empID > 0) {
            this.empID = empID;
        } else {
            this.empID = 1;
        }
    }

    public int getProjectID() {    
        return projectID;
    }

    public void setProjectID(int projectID) {
         if (projectID > 0) {
             this.projectID = projectID;
        } else {
             this.projectID = 1;
         }
    }

    public LocalDate getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(LocalDate dateFrom) {
        this.dateFrom = dateFrom;
    }

    public LocalDate getDateTo() {
        return dateTo;
    }

    public void setDateTo(LocalDate dateTo) {
        this.dateTo = dateTo;
    }

    public long getDuration() {
        return DAYS.between(this.getDateFrom(), this.getDateTo());
    }
    
    
    @Override
    public String toString() {
        return String.format("%4d %4d %10s %10s", getEmpID(), getProjectID(), getDateFrom(), getDateTo());   
    }
       
}
